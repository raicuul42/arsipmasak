import { a as jsxs, j as jsx } from "../ssr.js";
import { usePage, Head } from "@inertiajs/react";
import { C as Container, A as AppLayout } from "./Container-6bcb6060.js";
import ArticleBlock from "./ArticleBlock-557ab583.js";
import { P as Pagination } from "./Pagination-d7f6eb65.js";
import Filter from "./Filter-5be43929.js";
import { M as MetaTags } from "./MetaTags-fbca8517.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "clsx";
import "react";
import "./ApplicationLogo-30b7c836.js";
import "@heroicons/react/24/outline/index.js";
import "@heroicons/react/20/solid/index.js";
import "./Image-a9f36eea.js";
import "framer-motion";
import "react-lazy-load";
function Index({ params }) {
  const { data: articles, meta, links } = usePage().props.articles;
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx(Head, { title: params.title }),
    /* @__PURE__ */ jsx(
      MetaTags,
      {
        title: params.title,
        description: params.subtitle,
        url: route("articles.index")
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "bg-gray-950 pb-10 pt-16", children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h2", { className: "text-2xl font-bold tracking-tight text-white", children: params.title }),
        /* @__PURE__ */ jsx("p", { className: "text-lg leading-8 text-gray-300", children: params.subtitle })
      ] }),
      /* @__PURE__ */ jsx(Filter, {})
    ] }) }) }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs("div", { className: "py-24", children: [
      /* @__PURE__ */ jsx(ArticleBlock, { articles }),
      meta.has_pages && /* @__PURE__ */ jsx("div", { className: "mt-24", children: /* @__PURE__ */ jsx(Pagination, { meta, links }) })
    ] }) })
  ] });
}
Index.layout = (page) => /* @__PURE__ */ jsx(AppLayout, { children: page });
export {
  Index as default
};
