import { a as jsxs, j as jsx } from "../ssr.js";
import { Head } from "@inertiajs/react";
import { A as AppLayout } from "./Container-6bcb6060.js";
import { H as Header } from "./Header-49e81a9e.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "clsx";
import "react";
import "./ApplicationLogo-30b7c836.js";
import "./Filter-5be43929.js";
import "@heroicons/react/24/outline/index.js";
import "@heroicons/react/20/solid/index.js";
function Dashboard() {
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx(Head, { title: "Dashboard" }),
    /* @__PURE__ */ jsx(Header, { title: "Dashboard", subtitle: "Here you can find all the information about your application." })
  ] });
}
Dashboard.layout = (page) => /* @__PURE__ */ jsx(AppLayout, { children: page });
export {
  Dashboard as default
};
