import { a as jsxs, F as Fragment, j as jsx } from "../ssr.js";
import { ChatBubbleOvalLeftIcon, HeartIcon, PencilIcon } from "@heroicons/react/24/outline/index.js";
import { usePage, Link } from "@inertiajs/react";
import { useState } from "react";
import CommentForm from "./CommentForm-67430cf4.js";
import CommentOptions from "./CommentOptions-9bbf4f02.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "@headlessui/react";
import "clsx";
import "framer-motion";
import "@heroicons/react/20/solid/index.js";
import "@heroicons/react/20/solid";
import "./useSwal-1e8019da.js";
import "sweetalert";
import "./ReportModal-d21ba409.js";
import "./PrimaryButton-5fd12591.js";
import "./SecondaryButton-2a8d058c.js";
import "./Select-0829068d.js";
function CommentBlock({ comments }) {
  const { auth, article } = usePage().props;
  const [open, setOpen] = useState(false);
  const [attributes, setAttributes] = useState({
    body: "",
    url: "",
    method: "post",
    item: {},
    submitText: "Comment"
  });
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    open && /* @__PURE__ */ jsx(
      CommentForm,
      {
        ...{
          attributes,
          auth,
          open,
          close: () => setOpen(false)
        }
      }
    ),
    comments.length > 0 && /* @__PURE__ */ jsx("div", { className: "mt-6 space-y-6", children: comments.map((comment) => {
      var _a;
      return /* @__PURE__ */ jsxs("div", { className: "flex", children: [
        /* @__PURE__ */ jsx("div", { className: "mr-4 flex-shrink-0", children: /* @__PURE__ */ jsx(
          "img",
          {
            className: "h-10 w-10 rounded-full",
            src: comment.author.gravatar,
            alt: comment.author.name
          }
        ) }),
        /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("h4", { className: "font-semibold", children: [
              comment.author.name,
              /* @__PURE__ */ jsx("small", { className: "ml-2 text-sm text-gray-400", children: comment.created_at })
            ] }),
            auth.user && /* @__PURE__ */ jsx(CommentOptions, { ...{ auth, article, comment } })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-1 leading-relaxed text-gray-400", children: [
            /* @__PURE__ */ jsx(
              "div",
              {
                className: "prose prose-invert prose-sky prose-pre:bg-gray-800",
                dangerouslySetInnerHTML: { __html: comment.markdown_formatted }
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "mt-4 flex items-center gap-x-4 py-2", children: [
              comment.can_be_replied && /* @__PURE__ */ jsxs(
                "button",
                {
                  onClick: () => {
                    setOpen(true);
                    setAttributes({
                      ...attributes,
                      body: null,
                      url: route("comments.reply", [comment]),
                      item: comment,
                      submitText: "Reply"
                    });
                  },
                  className: "flex h-6 w-6 items-center text-gray-500 hover:text-white focus:outline-none",
                  children: [
                    /* @__PURE__ */ jsx(ChatBubbleOvalLeftIcon, { className: "h-4 w-4 shrink-0" }),
                    comment.children_count > 0 && /* @__PURE__ */ jsx("span", { className: "ml-2 text-sm", children: comment.children_count })
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                Link,
                {
                  as: "button",
                  method: "post",
                  preserveScroll: true,
                  href: route("comments.like", [comment]),
                  className: "inline-flex h-6 w-6 items-center justify-center text-gray-500 hover:text-pink-500 focus:outline-none",
                  children: [
                    /* @__PURE__ */ jsx(HeartIcon, { className: "h-4 w-4 shrink-0" }),
                    comment.likes_count > 0 && /* @__PURE__ */ jsx("span", { className: "ml-2 text-sm", children: comment.likes_count })
                  ]
                }
              ),
              ((_a = auth.user) == null ? void 0 : _a.id) === comment.author.id && /* @__PURE__ */ jsx(
                "button",
                {
                  onClick: () => {
                    setOpen(true);
                    setAttributes({
                      url: route("comments.update", [article, comment]),
                      body: comment.body,
                      item: comment,
                      method: "put",
                      submitText: "Update"
                    });
                  },
                  className: "inline-flex h-6 w-6 items-center text-gray-500 hover:text-white focus:outline-none",
                  children: /* @__PURE__ */ jsx(PencilIcon, { className: "h-4 w-4" })
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsx(CommentBlock, { comments: comment.children })
        ] })
      ] }, comment.id);
    }) })
  ] });
}
export {
  CommentBlock as default
};
