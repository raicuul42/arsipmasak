import { a as jsxs, F as Fragment, j as jsx } from "../ssr.js";
import { A as AppLayout } from "./Container-6bcb6060.js";
import DeleteUserForm from "./DeleteUserForm-70767877.js";
import UpdatePasswordForm from "./UpdatePasswordForm-322d0ca5.js";
import UpdateProfileInformation from "./UpdateProfileInformationForm-8497ba59.js";
import { Head } from "@inertiajs/react";
import { H as Header } from "./Header-49e81a9e.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "clsx";
import "react";
import "./ApplicationLogo-30b7c836.js";
import "./Filter-5be43929.js";
import "@heroicons/react/24/outline/index.js";
import "@heroicons/react/20/solid/index.js";
import "./InputError-37439609.js";
import "./InputLabel-2bb2243f.js";
import "./SecondaryButton-2a8d058c.js";
import "./TextInput-1cee5103.js";
import "./PrimaryButton-5fd12591.js";
function Edit({ mustVerifyEmail, status }) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Profile" }),
    /* @__PURE__ */ jsx(Header, { title: "Profile", subtitle: "Update your account's profile information and email address." }),
    /* @__PURE__ */ jsx("div", { className: "py-12", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-7xl space-y-6 sm:px-6 lg:px-8", children: [
      /* @__PURE__ */ jsx("div", { className: "bg-gray-900 p-4 sm:rounded-lg sm:p-8", children: /* @__PURE__ */ jsx(
        UpdateProfileInformation,
        {
          mustVerifyEmail,
          status,
          className: "max-w-xl"
        }
      ) }),
      /* @__PURE__ */ jsx("div", { className: "bg-gray-900 p-4 sm:rounded-lg sm:p-8", children: /* @__PURE__ */ jsx(UpdatePasswordForm, { className: "max-w-xl" }) }),
      /* @__PURE__ */ jsx("div", { className: "bg-gray-900 p-4 sm:rounded-lg sm:p-8", children: /* @__PURE__ */ jsx(DeleteUserForm, { className: "max-w-xl" }) })
    ] }) })
  ] });
}
Edit.layout = (page) => /* @__PURE__ */ jsx(AppLayout, { children: page });
export {
  Edit as default
};
