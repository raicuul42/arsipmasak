import { j as jsx, a as jsxs } from "../ssr.js";
import { I as Image } from "./Image-a9f36eea.js";
import { Link } from "@inertiajs/react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "framer-motion";
import "react-lazy-load";
function ArticleBlock({ articles }) {
  return /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-x-16 gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3", children: articles.map((article) => /* @__PURE__ */ jsxs("article", { className: "flex flex-col items-start justify-between", children: [
    /* @__PURE__ */ jsxs("div", { className: "relative w-full", children: [
      /* @__PURE__ */ jsx(
        Image,
        {
          src: article.thumbnail,
          alt: "",
          className: "aspect-[16/9] w-full rounded-2xl bg-black object-cover sm:aspect-[2/1] lg:aspect-[3/2]"
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-6 max-w-xl", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-x-4 text-xs", children: [
        /* @__PURE__ */ jsx("time", { dateTime: article.published_at, className: "text-gray-400", children: article.published_at }),
        /* @__PURE__ */ jsx(
          Link,
          {
            href: article.category.href,
            className: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100",
            children: article.category.name
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "group relative", children: [
        /* @__PURE__ */ jsx("h3", { className: "mt-3 line-clamp-1 text-lg font-semibold leading-6 text-gray-300 group-hover:text-white", children: /* @__PURE__ */ jsxs(Link, { href: article.href, children: [
          /* @__PURE__ */ jsx("span", { className: "absolute inset-0" }),
          article.title
        ] }) }),
        /* @__PURE__ */ jsx("p", { className: "mt-5 line-clamp-3 text-sm leading-6 text-gray-400", children: article.excerpt })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "relative mt-8 flex items-center gap-x-4", children: [
        /* @__PURE__ */ jsx("img", { src: article.author.picture, alt: "", className: "h-10 w-10 rounded-full bg-gray-900" }),
        /* @__PURE__ */ jsxs("div", { className: "text-sm leading-6", children: [
          /* @__PURE__ */ jsx("p", { className: "font-semibold text-white", children: /* @__PURE__ */ jsxs("a", { href: article.author.href, children: [
            /* @__PURE__ */ jsx("span", { className: "absolute inset-0" }),
            article.author.name
          ] }) }),
          /* @__PURE__ */ jsx("p", { className: "text-gray-400", children: article.author.role })
        ] })
      ] })
    ] })
  ] }, article.id)) });
}
export {
  ArticleBlock as default
};
