import { j as jsx } from "../ssr.js";
import { motion } from "framer-motion";
import LazyLoad from "react-lazy-load";
function Image({ className, alt, height, src, width }) {
  return /* @__PURE__ */ jsx(LazyLoad, { height, width, threshold: 0.95, children: /* @__PURE__ */ jsx(
    motion.img,
    {
      initial: { opacity: 0, scale: 0.9 },
      whileInView: { opacity: 1, scale: 1 },
      viewport: { once: true },
      className,
      src,
      alt
    }
  ) });
}
export {
  Image as I
};
