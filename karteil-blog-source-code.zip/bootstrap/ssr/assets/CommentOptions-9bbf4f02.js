import { a as jsxs, j as jsx } from "../ssr.js";
import { useState, Fragment } from "react";
import { Menu, Transition } from "@headlessui/react";
import { EllipsisVerticalIcon } from "@heroicons/react/20/solid";
import { u as useSwal } from "./useSwal-1e8019da.js";
import clsx from "clsx";
import { TrashIcon, ExclamationCircleIcon } from "@heroicons/react/24/outline/index.js";
import ReportModal from "./ReportModal-d21ba409.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react";
import "@inertiajs/react/server";
import "sweetalert";
import "./PrimaryButton-5fd12591.js";
import "./SecondaryButton-2a8d058c.js";
import "./Select-0829068d.js";
function CommentOptions({ auth, article, comment }) {
  var _a, _b;
  const { ask } = useSwal();
  const [showReportModal, setShowReportModal] = useState(false);
  return /* @__PURE__ */ jsxs(Menu, { as: "div", className: "relative inline-block text-left", children: [
    /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Menu.Button, { className: "flex justify-end", children: /* @__PURE__ */ jsx(EllipsisVerticalIcon, { className: "-mr-1 h-5 w-5 text-gray-300", "aria-hidden": "true" }) }) }),
    /* @__PURE__ */ jsx(ReportModal, { comment, show: showReportModal, onClose: setShowReportModal }),
    /* @__PURE__ */ jsx(
      Transition,
      {
        as: Fragment,
        enter: "transition ease-out duration-100",
        enterFrom: "transform opacity-0 scale-95",
        enterTo: "transform opacity-100 scale-100",
        leave: "transition ease-in duration-75",
        leaveFrom: "transform opacity-100 scale-100",
        leaveTo: "transform opacity-0 scale-95",
        children: /* @__PURE__ */ jsx(Menu.Items, { className: "absolute right-4 top-0 z-10 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none", children: /* @__PURE__ */ jsxs("div", { className: "py-1", children: [
          ((_a = auth.user) == null ? void 0 : _a.id) === comment.author.id && /* @__PURE__ */ jsx(Menu.Item, { children: ({ active }) => /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: () => {
                ask({
                  url: route("comments.destroy", [article, comment]),
                  message: `The comment you are about to delete is created ${comment.created_at}, Are you sure you want to delete this comment?`,
                  method: "delete"
                });
              },
              className: clsx(
                active ? "bg-gray-100 text-gray-900" : "text-gray-700",
                "flex w-full items-center gap-x-2 px-4 py-2 text-left text-sm"
              ),
              children: [
                /* @__PURE__ */ jsx(TrashIcon, { className: "h-5 w-5" }),
                "Delete comment"
              ]
            }
          ) }),
          ((_b = auth.user) == null ? void 0 : _b.id) !== comment.author.id && /* @__PURE__ */ jsx(Menu.Item, { children: ({ active }) => /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: () => setShowReportModal(true),
              className: clsx(
                active ? "bg-gray-100 text-gray-900" : "text-gray-700",
                "flex w-full items-center gap-x-2 px-4 py-2 text-left text-sm"
              ),
              children: [
                /* @__PURE__ */ jsx(ExclamationCircleIcon, { className: "h-5 w-5" }),
                "Report"
              ]
            }
          ) })
        ] }) })
      }
    )
  ] });
}
export {
  CommentOptions as default
};
