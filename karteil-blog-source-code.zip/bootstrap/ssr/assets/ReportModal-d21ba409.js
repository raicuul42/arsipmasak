import { j as jsx, a as jsxs } from "../ssr.js";
import { P as PrimaryButton } from "./PrimaryButton-5fd12591.js";
import { M as Modal, S as SecondaryButton } from "./SecondaryButton-2a8d058c.js";
import { S as Select } from "./Select-0829068d.js";
import { useForm } from "@inertiajs/react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "clsx";
import "react";
import "@headlessui/react";
const reasons = [
  "This is a hate speech",
  "Contains inappropriate content",
  "This is a spam",
  "This is a scam",
  "This is a fake news"
];
function ReportModal({ comment, show, onClose }) {
  const { data, setData, processing, post, errors } = useForm({
    reason: ""
  });
  function submit(e) {
    e.preventDefault();
    post(route("comments.reportSpam", [comment]), {
      preserveScroll: true,
      onSuccess: () => onClose(false)
    });
  }
  return /* @__PURE__ */ jsx(Modal, { show, onClose: () => onClose(false), children: /* @__PURE__ */ jsxs("div", { className: "p-6", children: [
    /* @__PURE__ */ jsx("h4", { className: "mb-4 text-lg font-semibold", children: "Report Comment" }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-2", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "reason", className: "mb-2 block text-gray-500", children: "Select a reason for reporting this comment" }),
        /* @__PURE__ */ jsx(
          Select,
          {
            placeholder: "Select a reason",
            onChange: (e) => setData("reason", e.target.value),
            name: "reason",
            id: "reason",
            options: reasons.map((reason, index) => ({
              value: reason,
              label: reason
            }))
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-end gap-x-1", children: [
        /* @__PURE__ */ jsx(SecondaryButton, { type: "button", onClick: () => onClose(false), children: "Cancel" }),
        /* @__PURE__ */ jsx(PrimaryButton, { type: "submit", children: "Report" })
      ] })
    ] })
  ] }) });
}
export {
  ReportModal as default
};
