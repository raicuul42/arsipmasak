import { j as jsx, a as jsxs } from "../ssr.js";
import { C as Container } from "./Container-6bcb6060.js";
function Header({ title, subtitle }) {
  return /* @__PURE__ */ jsx("div", { className: "border-b border-t border-gray-800 bg-gray-900 py-10 sm:py-20", children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx("div", { className: "max-w-xl", children: /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx("h2", { className: "mb-2 text-3xl font-bold tracking-tight text-white", children: title }),
    /* @__PURE__ */ jsx("p", { className: "text-lg leading-8 text-gray-400", children: subtitle })
  ] }) }) }) });
}
export {
  Header as H
};
