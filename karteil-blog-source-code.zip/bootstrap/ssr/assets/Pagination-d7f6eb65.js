import { j as jsx, a as jsxs } from "../ssr.js";
import { ChevronDoubleLeftIcon, ChevronLeftIcon, ChevronRightIcon, ChevronDoubleRightIcon } from "@heroicons/react/20/solid/index.js";
import { Link } from "@inertiajs/react";
function Pagination({ meta, links }) {
  return /* @__PURE__ */ jsx("div", { className: "flex justify-center px-5 pt-8", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
    meta.current_page !== 1 && /* @__PURE__ */ jsx(
      Link,
      {
        href: links.first,
        className: "grid h-10 w-10 cursor-pointer place-items-center rounded-full bg-gray-900 shadow-[8.05051px_24.1515px_89.4501px_-11.6285px_rgba(22,52,80,0.05)] backdrop-blur-xl transition duration-300 hover:bg-gray-800",
        children: /* @__PURE__ */ jsx(ChevronDoubleLeftIcon, { className: "h-6 w-6" })
      }
    ),
    links.prev ? /* @__PURE__ */ jsx(
      Link,
      {
        href: links.prev,
        className: "grid h-10 w-10 cursor-pointer place-items-center rounded-full bg-gray-900 shadow-[8.05051px_24.1515px_89.4501px_-11.6285px_rgba(22,52,80,0.05)] backdrop-blur-xl transition duration-300 hover:bg-gray-800",
        children: /* @__PURE__ */ jsx(ChevronLeftIcon, { className: "h-6 w-6" })
      }
    ) : /* @__PURE__ */ jsx("div", { className: "grid h-10 w-10 place-items-center rounded-full bg-gray-900 opacity-25 shadow-[8.05051px_24.1515px_89.4501px_-11.6285px_rgba(22,52,80,0.05)] backdrop-blur-xl transition duration-300", children: /* @__PURE__ */ jsx(ChevronLeftIcon, { className: "h-6 w-6" }) }),
    /* @__PURE__ */ jsx("div", { className: "grid w-16 place-items-center", children: /* @__PURE__ */ jsxs("div", { className: "relative h-12 w-14", children: [
      /* @__PURE__ */ jsx("div", { className: "absolute right-[60%] top-0 text-xl font-semibold transition-all duration-300", children: meta.from }),
      Array.from(Array(meta.total).keys()).map((i) => /* @__PURE__ */ jsx(
        "div",
        {
          className: "absolute -top-5 right-[20%] text-xl font-semibold opacity-0 transition-all duration-300",
          children: i
        },
        i
      )),
      /* @__PURE__ */ jsx("div", { className: "absolute right-1/2 top-1/2 h-[0.5px] w-10 -translate-y-1/2 translate-x-1/2 -rotate-45 rounded-full bg-gray-400" }),
      /* @__PURE__ */ jsx("div", { className: "absolute bottom-1 left-[60%] text-sm", children: meta.total })
    ] }) }),
    links.next ? /* @__PURE__ */ jsx(
      Link,
      {
        href: links.next,
        className: "grid h-10 w-10 cursor-pointer place-items-center rounded-full bg-gray-900 shadow-[8.05051px_24.1515px_89.4501px_-11.6285px_rgba(22,52,80,0.05)] backdrop-blur-xl transition duration-300 hover:bg-gray-800",
        children: /* @__PURE__ */ jsx(ChevronRightIcon, { className: "h-6 w-6" })
      }
    ) : /* @__PURE__ */ jsx("div", { className: "grid h-10 w-10 place-items-center rounded-full bg-gray-900 opacity-25 shadow-[8.05051px_24.1515px_89.4501px_-11.6285px_rgba(22,52,80,0.05)] backdrop-blur-xl transition duration-300", children: /* @__PURE__ */ jsx(ChevronRightIcon, { className: "h-6 w-6" }) }),
    meta.to !== meta.total && /* @__PURE__ */ jsx(
      Link,
      {
        href: links.last,
        className: "grid h-10 w-10 cursor-pointer place-items-center rounded-full bg-gray-900 shadow-[8.05051px_24.1515px_89.4501px_-11.6285px_rgba(22,52,80,0.05)] backdrop-blur-xl transition duration-300 hover:bg-gray-800 hover:bg-white",
        children: /* @__PURE__ */ jsx(ChevronDoubleRightIcon, { className: "h-6 w-6" })
      }
    )
  ] }) });
}
export {
  Pagination as P
};
