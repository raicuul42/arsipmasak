import { a as jsxs, j as jsx } from "../ssr.js";
import { Head, Link } from "@inertiajs/react";
import { C as Container, A as AppLayout } from "./Container-6bcb6060.js";
import ArticleBlock from "./ArticleBlock-557ab583.js";
import { M as MetaTags } from "./MetaTags-fbca8517.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "clsx";
import "react";
import "./ApplicationLogo-30b7c836.js";
import "./Filter-5be43929.js";
import "@heroicons/react/24/outline/index.js";
import "@heroicons/react/20/solid/index.js";
import "./Image-a9f36eea.js";
import "framer-motion";
import "react-lazy-load";
function Home({ articles, popularArticles, gotoLatestArticle }) {
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx(Head, { title: "Read it when you relax" }),
    /* @__PURE__ */ jsx(
      MetaTags,
      {
        title: "Read it when you relax",
        description: "Read it when you relax",
        url: route("home")
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "relative isolate overflow-hidden bg-gray-950", children: [
      /* @__PURE__ */ jsxs(
        "svg",
        {
          className: "absolute inset-0 -z-10 h-full w-full stroke-white/10 [mask-image:radial-gradient(100%_100%_at_top_right,white,transparent)]",
          "aria-hidden": "true",
          children: [
            /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx(
              "pattern",
              {
                id: "983e3e4c-de6d-4c3f-8d64-b9761d1534cc",
                width: 200,
                height: 200,
                x: "50%",
                y: -1,
                patternUnits: "userSpaceOnUse",
                children: /* @__PURE__ */ jsx("path", { d: "M.5 200V.5H200", fill: "none" })
              }
            ) }),
            /* @__PURE__ */ jsx("svg", { x: "50%", y: -1, className: "overflow-visible fill-gray-800/20", children: /* @__PURE__ */ jsx(
              "path",
              {
                d: "M-200 0h201v201h-201Z M600 0h201v201h-201Z M-400 600h201v201h-201Z M200 800h201v201h-201Z",
                strokeWidth: 0
              }
            ) }),
            /* @__PURE__ */ jsx(
              "rect",
              {
                width: "100%",
                height: "100%",
                strokeWidth: 0,
                fill: "url(#983e3e4c-de6d-4c3f-8d64-b9761d1534cc)"
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "absolute left-[calc(50%-4rem)] top-10 -z-10 transform-gpu blur-3xl sm:left-[calc(50%-18rem)] lg:left-48 lg:top-[calc(50%-30rem)] xl:left-[calc(50%-24rem)]",
          "aria-hidden": "true",
          children: /* @__PURE__ */ jsx(
            "div",
            {
              className: "aspect-[1108/632] w-[69.25rem] bg-gradient-to-r from-[#80caff] to-[#4f46e5] opacity-20",
              style: {
                clipPath: "polygon(73.6% 51.7%, 91.7% 11.8%, 100% 46.4%, 97.4% 82.2%, 92.5% 84.9%, 75.7% 64%, 55.3% 47.5%, 46.5% 49.4%, 45% 62.9%, 50.3% 87.2%, 21.3% 64.1%, 0.1% 100%, 5.4% 51.1%, 21.4% 63.9%, 58.9% 0.2%, 73.6% 51.7%)"
              }
            }
          )
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "mx-auto max-w-7xl px-6 pb-24 pt-10 sm:pb-24 lg:flex lg:px-8 lg:py-24", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-2xl flex-shrink-0 lg:mx-0 lg:max-w-xl lg:pt-8", children: [
        /* @__PURE__ */ jsx("div", { className: "mt-24 sm:mt-32 lg:mt-16", children: /* @__PURE__ */ jsx(Link, { href: gotoLatestArticle, className: "inline-flex space-x-6", children: /* @__PURE__ */ jsx("span", { className: "rounded-full bg-sky-500/10 px-3 py-1 text-sm font-semibold leading-6 text-sky-400 ring-1 ring-inset ring-sky-500/20", children: "What's new" }) }) }),
        /* @__PURE__ */ jsx("h1", { className: "mt-10 text-4xl font-bold tracking-tight text-white sm:text-6xl", children: "Point of You" }),
        /* @__PURE__ */ jsx("p", { className: "mt-6 text-lg leading-8 text-gray-300", children: "Read it when you relax is a knowledge base for all the questions you have about our products." })
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs("div", { className: "py-24", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-6", children: [
        /* @__PURE__ */ jsx("h4", { className: "text-xl font-semibold", children: "Weekly Popular" }),
        /* @__PURE__ */ jsx("p", { className: "text-gray-500", children: "The most popular articles over the past 7 days" })
      ] }),
      /* @__PURE__ */ jsx(ArticleBlock, { articles: popularArticles }),
      /* @__PURE__ */ jsx("div", { className: "mt-12 text-right", children: /* @__PURE__ */ jsx(Link, { className: "text-sky-500 hover:underline", href: route("articles.filter", ["week"]), children: "See more popular articles" }) }),
      /* @__PURE__ */ jsxs("div", { className: "mb-6 mt-24", children: [
        /* @__PURE__ */ jsx("h4", { className: "text-xl font-semibold", children: "Latest Articles" }),
        /* @__PURE__ */ jsx("p", { className: "text-gray-500", children: "The most recent articles on the site" })
      ] }),
      /* @__PURE__ */ jsx(ArticleBlock, { articles }),
      /* @__PURE__ */ jsx("div", { className: "mt-12 text-right", children: /* @__PURE__ */ jsx(Link, { className: "text-sky-500 hover:underline", href: route("articles.index"), children: "See more articles" }) })
    ] }) })
  ] });
}
Home.layout = (page) => /* @__PURE__ */ jsx(AppLayout, { children: page });
export {
  Home as default
};
