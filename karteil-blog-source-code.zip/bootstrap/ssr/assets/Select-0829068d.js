import { a as jsxs, j as jsx } from "../ssr.js";
function Select({ options, placeholder = "Select an options", ...props }) {
  return /* @__PURE__ */ jsxs(
    "select",
    {
      className: "block w-full rounded-md border-0 bg-white/5 py-1.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-blue-500 sm:text-sm sm:leading-6",
      ...props,
      children: [
        /* @__PURE__ */ jsx("option", { value: "", children: placeholder }),
        options.map((option, index) => /* @__PURE__ */ jsx("option", { value: option.value, children: option.label }, index))
      ]
    }
  );
}
export {
  Select as S
};
